#Making the thing that reads the thing.csv (dont worry about it)
# Import necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from textblob import TextBlob #reccomended to me by we3 schools and chatgpt, had to download via terminal though

# 1. DATA LOADING
# a. Load the dataset
df = pd.read_csv(r"C:\Users\Sebas\OneDrive\Desktop\SCA Assignment\series_movies_descriptions.csv") #THE DISTAIN I HAVE FOR CSV READING

# b. Display the first few rows
print("First 5 rows of the dataset:")
print(df.head())

plt.figure(figsize=(8,5))
sns.histplot(df['Rating'], bins=10, kde=True)
plt.title('Distribution of Ratings')
plt.xlabel('Rating')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()
print("\nRating counts:")
print(df['Rating'].value_counts())
def compute_polarity(text):
    return TextBlob(str(text)).sentiment.polarity
df['Polarity'] = df['description'].apply(compute_polarity)
df['Sentiment Label'] = df['Polarity'].apply(lambda x: 'Positive' if x > 0 else 'Negative')
plt.figure(figsize=(6,4))
df['Sentiment Label'].value_counts().plot(kind='bar', color=['skyblue', 'salmon'])
plt.title('Sentiment Distribution')
plt.xlabel('Sentiment')
plt.ylabel('Count')
plt.xticks(rotation=0)
plt.grid(axis='y')
plt.show()   #all credit to codecademy for sorting me out with graphing, super nice course they have
print("\nUpdated DataFrame with Polarity and Sentiment:")
print(df[['description', 'Polarity', 'Sentiment Label']].head())
