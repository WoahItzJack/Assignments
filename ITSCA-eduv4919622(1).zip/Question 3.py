import requests
from bs4 import BeautifulSoup
import pandas as pd
import re

def get_job_data(search_term):
    formatted_search = search_term.replace(" ", "-")
    base_url = f"https://www.careerjunction.co.za/jobs/{formatted_search}"
    
    headers = {
        'User-Agent': 'Mozilla/5.0'
    }

    try:
        response = requests.get(base_url, headers=headers, timeout=10)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return []

    soup = BeautifulSoup(response.text, 'html.parser')

    # Flexible matching for dynamic class names
    job_cards = soup.find_all('div', class_=re.compile(r'^cardWrapper'))

    job_list = []
    for job in job_cards:
        def extract_text(class_name):
            tag = job.find('div', class_=re.compile(f'^{class_name}'))
            return tag.get_text(strip=True) if tag else "N/A"

        title_tag = job.find('h3')
        title = title_tag.get_text(strip=True) if title_tag else "N/A"

        job_list.append({
            "Title": title,
            "Recruiter": extract_text("cardCompanyName"),
            "Salary": extract_text("cardSalary"),
            "Position": extract_text("cardEmploymentType"),
            "Location": extract_text("cardLocation"),
            "Date Posted": extract_text("cardDate"),
        })

    return job_list


if __name__ == "__main__":
    search_term = input("Enter the job title you want to search for: ").strip()
    job_list = get_job_data(search_term)

    if job_list:
        df = pd.DataFrame(job_list)
        filename = f"{search_term.replace(' ', '_')}_job-results.csv"
        df.to_csv(filename, index=False)
        print(f"✅ Saved {len(df)} job postings to '{filename}'")
    else:
        print("⚠️ No job data found or failed to retrieve results.")
