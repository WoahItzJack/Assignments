import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r"C:/Users/Sebas/OneDrive/Desktop/SCA Assignment/petrolprices.csv", delimiter=';')
print("Initial Data Preview:")
print(df.head())

# 3. Data Preprocessing

# a. Set Year and Month as index
df.set_index(['Year', 'Month'], inplace=True)

# b. Create 'Price Difference' column (Diesel - Petrol)
df['Price Difference'] = df['Diesel'] - df['Petrol']
print("\nData with Price Difference:")
print(df.head())

# 4. Year-wise Data Segmentation

# a. Data for 2023
df_2023 = df.loc[2023]
print("\n2023 Data:")
print(df_2023)

# b. Data for 2024
df_2024 = df.loc[2024]
print("\n2024 Data:")
print(df_2024)

# 5. Data Visualization

# a. Line charts for 2023
plt.figure(figsize=(10, 5))
#for memes and customizability i asked chatgpt to get me the exact color index values of the creeper from minecraft
# Creeper color scheme
petrol_color = "#3A9D23"  # Main Creeper green
diesel_color = '#1E4D2B'  # Darker green
#^COOL THAT YOU CAN TOGGLE THE COLOR IN THE CODE BY CLICKING THE BOX

plt.plot(df_2023.index.get_level_values('Month'), df_2023['Petrol'], marker='o', color=petrol_color, label='Petrol Price')
plt.plot(df_2023.index.get_level_values('Month'), df_2023['Diesel'], marker='s', color=diesel_color, label='Diesel Price')

plt.title('Fuel Prices - 2023', color='#000000')
plt.xlabel('Month', color='#000000')
plt.ylabel('Price (R)', color='#000000')
plt.legend()
plt.grid(True, color='#666666', linestyle='--', linewidth=0.5)
plt.xticks(rotation=45, color='#000000')
plt.yticks(color='#000000')
plt.tight_layout()
plt.show()

#i dont feel like doing more custom colors so im going to stick with defualts for the rest
# b. Line charts for 2024
plt.figure(figsize=(10, 5))
plt.plot(df_2024.index.get_level_values('Month'), df_2024['Petrol'], marker='o', label='Petrol Price')
plt.plot(df_2024.index.get_level_values('Month'), df_2024['Diesel'], marker='s', label='Diesel Price')
plt.title('Fuel Prices - 2024')
plt.xlabel('Month')
plt.ylabel('Price (R)')
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# c. Combined line chart for 2023–2024
df_reset = df.reset_index()
months = df_reset['Year'].astype(str) + '-' + df_reset['Month']
plt.figure(figsize=(12, 6))
plt.plot(months, df_reset['Petrol'], label='Petrol Price', marker='o')
plt.plot(months, df_reset['Diesel'], label='Diesel Price', marker='s')
plt.xticks(rotation=45)
plt.title('Monthly Fuel Prices (2023–2024)')
plt.xlabel('Month')
plt.ylabel('Price (R)')
plt.legend()
plt.tight_layout()
plt.grid(True)
plt.show()

# d. Line chart for 'Price Difference'
plt.figure(figsize=(12, 5))
plt.plot(months, df_reset['Price Difference'], color='purple', marker='^', label='Price Difference')
plt.xticks(rotation=45)
plt.title('Monthly Price Difference (Diesel - Petrol)')
plt.xlabel('Month')
plt.ylabel('Difference (R)')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

# 6. Insights
print("\nInsights:")
print("- The 'Price Difference' line chart helps reveal which months diesel was more expensive than petrol and by how much.")
print("- If the trend shows narrowing gaps, it might suggest alignment in cost. Wider gaps could impact choices for vehicle owners or fleet operators.")
print("- Any consistent rise or fall in the price difference might indicate external influences like global oil trends, taxes, or subsidies.")
