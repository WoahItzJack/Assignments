import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans


df = pd.read_csv(r"C:\Users\Sebas\OneDrive\Desktop\SCA Assignment\customer_segmentation.csv", delimiter=';')
#its really odd that i cant get the csv to read unless i use the full path name to the file.
df = df.dropna()
df = df[['income', 'spending_score']]

plt.figure(figsize=(8, 6))
plt.scatter(df['income'], df['spending_score'], c='blue', s=50)
plt.title('Income vs Spending Score')
plt.xlabel('Income')
plt.ylabel('Spending Score')
plt.grid(True)
plt.show()

wcss = []
for k in range(1, 11):
    kmeans = KMeans(n_clusters=k, init='k-means++', random_state=42)
    kmeans.fit(df)
    wcss.append(kmeans.inertia_)

plt.figure(figsize=(8, 6))
plt.plot(range(1, 11), wcss, marker='o')
plt.title('Elbow Method for Optimal k')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('WCSS')
plt.grid(True)
plt.show()

optimal_k = 4  

kmeans = KMeans(n_clusters=optimal_k, init='k-means++', random_state=42)
df['cluster'] = kmeans.fit_predict(df)

colors = ['red', 'green', 'blue', 'purple', 'orange', 'cyan', 'magenta', 'yellow', 'brown', 'pink']
plt.figure(figsize=(8, 6))
for i in range(optimal_k):
    cluster_data = df[df['cluster'] == i]
    plt.scatter(cluster_data['income'], cluster_data['spending_score'],
                s=50, c=colors[i], label=f'Cluster {i}')

centroids = kmeans.cluster_centers_
plt.scatter(centroids[:, 0], centroids[:, 1], s=200, c='black', marker='X', label='Centroids')

plt.title('Customer Segments')
plt.xlabel('Income')
plt.ylabel('Spending Score')
plt.legend()
plt.grid(True)
plt.show()

print("\nSummary:")
print(f"{optimal_k} clusters were identified based on income and spending score.")
print("Each cluster appears to represent different customer behaviors, such as:")
print("- High income, high spending")
print("- Low income, high spending")
print("- Low income, low spending")
print("- High income, low spending")

print("\nMarketing Strategy Insight:")
print("Retailers can use these segments to tailor their advertisements:")
print("- Target high spenders with loyalty offers")
print("- Encourage low spenders with discounts or engagement campaigns")
print("- Offer luxury services to high-income customers with low spending")
